## Little RTS
    
    * Python 3.2.2
    * Pygame 1.9.2a0

**Features:**

*	The screen is divided into a map area displaying the game world, an interface containing commands and information about the teams and a radar overview the entire map.
*	There are different information screens depending on the selected type of unit.
*	The units have agressive and pasive stance.
*	Radar shows warnings when an ally unit is attacked
*	Population limit
*	The units level up: by beat enemy units, their stats increase


http://youtu.be/rb7t5IPHRJY
