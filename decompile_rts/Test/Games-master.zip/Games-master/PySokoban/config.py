# -*- coding: utf-8 -*-

# marcos.diaz.cast@gmail.com

class Config:
    widthwindow  = 500
    heightwindow = 500
    size_window  = 500, 500
    size_tile    = 50 # 50 x 50
    pathlevels   = 'levels/'
    pathsprites  = 'sprites/'
    backcolor    = (46, 46, 46)
